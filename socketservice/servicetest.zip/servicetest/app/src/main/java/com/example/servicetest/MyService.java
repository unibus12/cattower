package com.example.servicetest;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class MyService extends Service {
    private Socket socket;
    private static final String TAG="mytag";
    public MyService() {

    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("ServerThread", "startThread");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        int step1 = intent.getIntExtra("step",0);
        Log.d("step ", Integer.toString(step1));
        if(step1 == 1) {
            ConnectThread thread = new ConnectThread("172.16.2.118");
            thread.start();
        }
        else if(step1 == 2){
            StartThread sthread = new StartThread();
            sthread.start();
        }
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    class ConnectThread extends Thread {
        String hostname;

        public ConnectThread(String addr) {
            hostname = addr;
        }

        public void run() {
            try { //클라이언트 소켓 생성
                int port = 35000;
                Log.d(TAG, "Socket 생성 start");
                socket = new Socket(hostname, port);
                Log.d(TAG, "Socket 생성, 연결.");
                InetAddress addr = socket.getInetAddress();
                String tmp = addr.getHostAddress();

            } catch (UnknownHostException uhe) { // 소켓 생성 시 전달되는 호스트(www.unknown-host.com)의 IP를 식별할 수 없음.
                Log.e(TAG, " 생성 Error : 호스트의 IP 주소를 식별할 수 없음.(잘못된 주소 값 또는 호스트 이름 사용)");
            } catch (IOException ioe) { // 소켓 생성 과정에서 I/O 에러 발생.
                Log.e(TAG, " 생성 Error : 네트워크 응답 없음");
            } catch (SecurityException se) { // security manager에서 허용되지 않은 기능 수행.
                Log.e(TAG, " 생성 Error : 보안(Security) 위반에 대해 보안 관리자(Security Manager)에 의해 발생. (프록시(proxy) 접속 거부, 허용되지 않은 함수 호출)");
            } catch (IllegalArgumentException le) { // 소켓 생성 시 전달되는 포트 번호(65536)이 허용 범위(0~65535)를 벗어남.
                Log.e(TAG, " 생성 Error : 메서드에 잘못된 파라미터가 전달되는 경우 발생.(0~65535 범위 밖의 포트 번호 사용, null 프록시(proxy) 전달)");
            }
        }
    }
    class StartThread extends Thread{

        int bytes;
        String Dtmp;
        int dlen;

        public StartThread(){

        }


        public String byteArrayToHex(byte[] a) {
            StringBuilder sb = new StringBuilder();
            for(final byte b: a)
                sb.append(String.format("%02x ", b&0xff));
            return sb.toString();
        }

        public void run(){

            // 데이터 송신
            try {

                String OutData = "SEND보냄\n";
                byte[] data = OutData.getBytes();
                OutputStream output = socket.getOutputStream();
                output.write(data);
                Log.d(TAG, "SEND\\n COMMAND 송신");

            } catch (IOException e) {
                e.printStackTrace();
                Log.d(TAG,"데이터 송신 오류");
            }

            // 데이터 수신
            try {
                Log.d(TAG, "데이터 수신 준비");

                //TODO:수신 데이터(프로토콜) 처리

                while (true) {
                    byte[] buffer = new byte[1024];

                    InputStream input = socket.getInputStream();

                    bytes = input.read(buffer);
                    Log.d(TAG, "byte = " + bytes);

                    //바이트 헥사(String)로 바꿔서 Dtmp String에 저장.
                    //####
                    Dtmp = byteArrayToHex(buffer);
                    Log.d(TAG, "buffer="+ buffer);
                    Dtmp = Dtmp.substring(0,bytes*4);
                    Log.d(TAG, "Dtmp="+ Dtmp);

                    String DSstep = "";
                    String DSplit = Dtmp.substring(0,2);
                    /*
                    for (int i=0; i<Dtmp.length();i++){
                        if(i%3==0) {
                            DSstep = Dtmp.substring(i,i+1);
                        }
                        if(i%3==1 && DSstep=="3") {
                            DSplit += Dtmp.substring(i,i+1);
                        }
                    }
                     */
                    Log.d(TAG, "DSplit="+ DSplit);

                    Intent showIntent = new Intent(getApplicationContext(), MainActivity.class);

                    showIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    showIntent.putExtra("step", 3);
                    showIntent.putExtra("data", Dtmp);
                    startActivity(showIntent);

                }
            }catch(IOException e){
                e.printStackTrace();
                Log.e(TAG,"수신 에러");
            }


        }

    }


}
