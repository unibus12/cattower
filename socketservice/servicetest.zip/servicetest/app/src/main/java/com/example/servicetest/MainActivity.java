package com.example.servicetest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.IOException;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    EditText editText,editText1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.text);
        editText1 = findViewById(R.id.text1);

        Button button1 = findViewById(R.id.button1);
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);

        //LocalBroadcastManager.getInstance(this).registerReceiver(
        //        mAlertReceiver, new IntentFilter("AlertServiceFilter"));

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MyService.class);
                intent.putExtra("step", 1);
                startService(intent);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), OneActivity.class);
                startActivity(intent);
            }
        });

        button3.setOnClickListener((view) -> {
            Intent intent = new Intent(getApplicationContext(), MyService.class);
            intent.putExtra("step", 2);
            startService(intent);
        });

    }

    @Override
    // 서비스쪽에서 던져준 데이터를 받기위한 메서드이다. processCommand는 출력하기위한 메소드
    // 처음이면 oncreate에서 확인 하고 그렇지 않으면(처음이 아니라면) oncreate에서 호출되지 않고
    // onNewIntent() 를 호출 하게 된다. 서비스 -> 액티비티에서 확인하는경우.
    protected void onNewIntent(Intent intent) {
        processIntent(intent);
        super.onNewIntent(intent);
    }

    private void processIntent(Intent intent){
        int n;
        char v;
        int i;
        String Intdata = "";
        int step1 = intent.getIntExtra("step",0);
        Log.d("TAG","recv step 확인");
        if(step1==3){
            Log.d("TAG","recv data 받음");
            String data = intent.getStringExtra("data");
            Log.d("data",data);

            for (i=0; i<data.length(); i=i+3){
                Log.d("String", "111");
                if (data.substring(i,i+2).equals("61")){
                    Log.d("String", "data1");
                }
                if(data.substring(i,i+1).equals("3")){
                    Intdata += data.substring(i+1,i+2);
                    Log.d("String", "숫자");
                    Log.d("String", Intdata);
                }
                if (data.substring(i,i+2).equals("20")){
                    Log.d("String", "break");
                    break;
                }
            }
            Log.d("data", String.valueOf(data.length()));
            /*
            n = Integer.parseInt(data.substring(0,2))+18;
            Log.d("int", String.valueOf(n));
            v = (char) n;
            Log.d("v", String.valueOf(v));

             */
            editText.setText(data);
            editText1.setText(Intdata);
        }
    }
}