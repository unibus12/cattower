package com.example.smartboard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ReturnActivity  extends Activity {
    TextView bluereturn, ModeStr;
    Button btnend;
    int i = 0;
    String[] str = {"ㅁ", "밤이 되었다", "사과"};
    String[] str2 = {"k", "it is apple", "sky"};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_return);
        ModeStr = (TextView) findViewById(R.id.ModeStr);
        bluereturn = (TextView) findViewById(R.id.bluereturn);
        btnend = (Button) findViewById(R.id.btnend);

        Intent intent = getIntent();
        String text = intent.getExtras().get("mode").toString();
        if(text != null) {
            ModeStr.setText(text);
        }

        btnend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bluereturn.setText(str[i]);
                i++;
                if(i==3){
                    i=0;
                }
            }
        });

    }
}